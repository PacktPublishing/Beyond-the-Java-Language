package com.packt;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest
{
	private Calculator calculator = null;
	
	public CalculatorTest()
	{
		calculator = new Calculator();
	}

	@Test
	public void testAdd()
	{
		assertEquals(25.5,  calculator.add(15.25, 10.25),  0.0);
	}

	@Test
	public void testSubtract()
	{
		assertEquals(5.0,  calculator.subtract(15.25, 10.25),  0.0);
	}

	@Test
	public void testDivide()
	{
		assertEquals(3.0,  calculator.divide(15.0, 5.0),  0.0);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testDivideIntInt()
	{
		assertEquals(15,  calculator.divide(15, 0),  0.0);
	}

	@Test
	public void testMultiply()
	{
		assertEquals(45,  calculator.multiply(4.5, 10.0),  0.0);
	}

}
