package com.packt;

public class Calculator
{	
	public double add(double num1, double num2)
	{
		return num1 + num2;
	}
	public double subtract(double num1, double num2)
	{
		return num1 - num2;
	}
	public double divide(double num1, double num2)
	{
		return num1 / num2;
	}
	public double divide(int num1, int num2) throws ArithmeticException
	{
		if(num2 == 0)
		{
			throw new ArithmeticException("Your divisor cannot be zero in the divide operation.");
		}
		return num1 / num2;
	}
	public double multiply(double num1, double num2)
	{
		return num1 * num2;
	}
}













/*


*/