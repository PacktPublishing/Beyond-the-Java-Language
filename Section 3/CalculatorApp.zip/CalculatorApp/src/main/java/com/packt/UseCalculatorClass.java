package com.packt;
import java.util.Locale;
public class UseCalculatorClass
{
	public static void main(String[] args)
	{
		Calculator calculator = new Calculator();		
		double answer = 0.0;
		System.out.println("Answer = " + answer);
		answer = calculator.add(25.0, 15.0);
		System.out.println("25.0 + 15.0 Answer = " + answer);
		answer = calculator.subtract(25.0, 15.0);
		System.out.println("25.0 - 15.0 Answer = " + answer);
		answer = calculator.multiply(25.0, 15.0);
		System.out.println("25.0 * 15.0 Answer = " + answer);
		answer = calculator.divide(25.0, 15.0);
		System.out.print("25.0 / 15.0 Answer = ");
		System.out.printf(Locale.ROOT, "%3.2f", answer);
	}
}
