package com.packt;
import java.sql.*;
public class TestingDatabaseConnection
{
	public static void main(String[] args)
	{
		//1. Registered the Driver
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Registered the Driver program...>>>>>");
		}
		catch (ClassNotFoundException ex)
		{
			System.out.println("Error: unable to load driver class!");
			System.exit(1);
		}
		//2. Make a connection
		String username = "root";
		String password = "root";
		String url = "jdbc:mysql://localhost:3306/bankdb";
		Connection dbConnection = null;
		try
		{
			dbConnection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection made to bankdb....>>>>");
			
//			Statement stmt = dbConnection.createStatement();
//			String values = "insert into branchtble values(1, 'London');";
//			int rowsAffected;
//			rowsAffected = stmt.executeUpdate(values);
//			System.out.println("rows affected in update are = " + rowsAffected);
			
//			String insertData = "insert into employeetbl values(?,?,?,?,?,?,?);";
//			PreparedStatement pstmt = dbConnection.prepareStatement(insertData);
//			pstmt.setInt(1, 1);
//			pstmt.setString(2, "Dominic");
//			pstmt.setString(3, "Bunger");
//			pstmt.setInt(4, 55);
//			pstmt.setDouble(5, 24889.23);
//			pstmt.setInt(6, 2);
//			pstmt.setInt(7, 3);
//			
//			pstmt.executeUpdate();
			
			String query = "select * from employeetbl where ID = ?;";
			PreparedStatement pstmt = dbConnection.prepareStatement(query);
			
			ResultSet rs2 = pstmt.executeQuery(query);
			rs2.next();
			int id = rs2.getInt(1);
			System.out.println("ID: " + id);
			String firstName = rs2.getString(2);
			System.out.println("First Name: " + firstName);
			
			
			
			dbConnection.close();//NEVER forget to close connections
		}
		catch (SQLException e)
		{
			System.out.println("Connection was NOT made to bankdb....>>>>");
			System.out.println(e.getMessage());
		}
	}
}
